package springmvc.controller;

import java.time.LocalDateTime; 

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value="/")
public class HomeController {
	
	@RequestMapping(/* path="/home", */ method=RequestMethod.GET)
	/* @RequestMapping("/home) */
	public String home(Model model) 
	{
		System.out.println("this is home url");
		model.addAttribute("name","Gaurav Subodh");
		model.addAttribute("id",96);
		return "index";
	}
	
	@RequestMapping("/about")
	public String about() {
		System.out.println("This is about url");
		return "about";
	}
	
	//modelandview example
	
	@RequestMapping("/help")
	public ModelAndView help() {
		System.out.println("This is help page");
		
		//creating model and view object
		ModelAndView modelandview =new ModelAndView();
		
		//setting the data
		modelandview.addObject("name","Gaurav");
		modelandview.addObject("rollnumber",24);
		LocalDateTime now = LocalDateTime.now();
		modelandview.addObject("time",now);
		
		//setting the view name
		modelandview.setViewName("help");
		
		return modelandview;
	}

}
